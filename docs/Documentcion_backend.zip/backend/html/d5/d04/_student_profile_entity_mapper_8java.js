var _student_profile_entity_mapper_8java =
[
    [ "com.unibague.magno.infrastructure.output.jpa.mapper.StudentProfileEntityMapper", "d7/dc4/interfacecom_1_1unibague_1_1magno_1_1infrastructure_1_1output_1_1jpa_1_1mapper_1_1_student_profile_entity_mapper.html", "d7/dc4/interfacecom_1_1unibague_1_1magno_1_1infrastructure_1_1output_1_1jpa_1_1mapper_1_1_student_profile_entity_mapper" ]
];
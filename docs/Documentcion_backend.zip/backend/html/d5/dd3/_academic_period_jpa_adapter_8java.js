var _academic_period_jpa_adapter_8java =
[
    [ "com.unibague.magno.infrastructure.output.jpa.adapter.AcademicPeriodJpaAdapter", "d4/da4/classcom_1_1unibague_1_1magno_1_1infrastructure_1_1output_1_1jpa_1_1adapter_1_1_academic_period_jpa_adapter.html", "d4/da4/classcom_1_1unibague_1_1magno_1_1infrastructure_1_1output_1_1jpa_1_1adapter_1_1_academic_period_jpa_adapter" ]
];